<?php

$server = "localhost";
$username = "root";
$password = "melvz";
$dbname = "Tapuyan_NHS_IMS";

$conn = mysqli_connect($server, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
